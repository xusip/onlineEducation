package com.tipdm.dao.role;

import java.util.List;
import com.tipdm.domain.Role;

public interface RoleDao {
	
	public List<Role> getRoleList();

}
