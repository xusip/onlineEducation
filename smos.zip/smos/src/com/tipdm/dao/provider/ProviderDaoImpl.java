package com.tipdm.dao.provider;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.mysql.cj.util.StringUtils;
import com.tipdm.domain.Provider;
import com.tipdm.util.JDBCUtils;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;


public class ProviderDaoImpl implements ProviderDao {
	private JdbcTemplate template = new JdbcTemplate(JDBCUtils.getDataSource());
	@Override
	public int add( Provider provider)
	{

			String sql = "insert into smbms_provider (proCode,proName,proDesc," +
					"proContact,proPhone,proAddress,proFax,createdBy,creationDate) " +
					"values(?,?,?,?,?,?,?,?,?)";
			Object[] params = {provider.getProCode(),provider.getProName(),provider.getProDesc(),
								provider.getProContact(),provider.getProPhone(),provider.getProAddress(),
								provider.getProFax(),provider.getCreatedBy(),provider.getCreationDate()};
		return  template.update(sql,params);
	}

	@Override
	public List<Provider> getProviderList( String proName,String proCode,int currentPageNo,int pageSize)
	{
		StringBuffer sql = new StringBuffer();
		sql.append("select * from smbms_provider where 1=1 ");
		List<Object> list = new ArrayList<Object>();
		if(!StringUtils.isNullOrEmpty(proName)){
			sql.append(" and proName like ?");
			list.add("%"+proName+"%");
		}
		if(!StringUtils.isNullOrEmpty(proCode)){
			sql.append(" and proCode like ?");
			list.add("%"+proCode+"%");
		}
		sql.append(" order by creationDate DESC limit ?,?");
		currentPageNo = (currentPageNo - 1) * pageSize;
		list.add(currentPageNo);
		list.add(pageSize);
		Object[] params = list.toArray();
		System.out.println("sql ----> " + sql.toString());
		return template.query(sql.toString(), new BeanPropertyRowMapper<Provider>(Provider.class),params);
	}
	@Override
	public int deleteProviderById( String delId)
	{
		String sql = "delete from smbms_provider where id=?";
		Object[] params = {delId};
		return  template.update(sql, delId);
	}
	@Override
	public List<Provider> getProviderList(String proName,String proCode)
	{
		StringBuffer sql = new StringBuffer();
		sql.append("select * from smbms_provider where 1=1 ");
		List<Object> list = new ArrayList<Object>();
		if(!StringUtils.isNullOrEmpty(proName)){
			sql.append(" and proName like ?");
			list.add("%"+proName+"%");
		}
		if(StringUtils.isNullOrEmpty(proCode)){
			sql.append(" and proCode like ?");
			list.add("%"+proCode+"%");
		}
		Object[] params = list.toArray();
		System.out.println("sql ----> " + sql.toString());
		System.out.println("params---->"+ Arrays.toString(params));
		return template.query(sql.toString(), new BeanPropertyRowMapper<Provider>(Provider.class),params);
	}
	@Override
	public Provider getProviderById( String id)
	{
			String sql = "select * from smbms_provider where id=?";
			Object[] params = {id};
			return template.queryForObject(sql, new BeanPropertyRowMapper<Provider>(Provider.class), id);
	}
	@Override
	public int modify( Provider provider)
	{
			String sql = "update smbms_provider set proName=?,proDesc=?,proContact=?," +
					"proPhone=?,proAddress=?,proFax=?,modifyBy=?,modifyDate=? where id = ? ";
			Object[] params = {provider.getProName(),provider.getProDesc(),provider.getProContact(),provider.getProPhone(),provider.getProAddress(),
					provider.getProFax(),provider.getModifyBy(),provider.getModifyDate(),provider.getId()};
			return template.update(sql,params);
	}
    @Override
    public int getProviderCount(String queryProName,String queryProCode) {
		StringBuffer sql = new StringBuffer();
		sql.append("select count(1) from smbms_provider where 1=1 ");
		List<Object> list = new ArrayList<Object>();
		if (!StringUtils.isNullOrEmpty(queryProName)) {
			sql.append(" and proName like ?");
			list.add("%" + queryProName + "%");
		}
		if (!StringUtils.isNullOrEmpty(queryProCode)) {
			sql.append("and proCode like ?");
			list.add("%"+ queryProCode+ "%");
		}
		Object[] params = list.toArray();
		System.out.println("sql ----> " + sql.toString());
		System.out.println("params---->"+ Arrays.toString(params));
		return template.queryForObject(sql.toString(), Integer.class, params);
    }

}
