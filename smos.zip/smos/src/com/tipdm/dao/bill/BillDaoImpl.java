package com.tipdm.dao.bill;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import com.mysql.cj.util.StringUtils;
import com.tipdm.domain.Bill;
import com.tipdm.util.JDBCUtils;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;


public class BillDaoImpl implements BillDao {

	private JdbcTemplate template = new JdbcTemplate(JDBCUtils.getDataSource());
	@Override
	public int add(Bill bill) {
		String sql = "insert into smbms_bill (billCode,productName,productDesc," +
				"productUnit,productCount,totalPrice,isPayment,providerId,createdBy,creationDate) " +
				"values(?,?,?,?,?,?,?,?,?,?)";
		Object[] params = {bill.getBillCode(),bill.getProductName(),bill.getProductDesc(),
				bill.getProductUnit(),bill.getProductCount(),bill.getTotalPrice(),bill.getIsPayment(),
				bill.getProviderId(),bill.getCreatedBy(),bill.getCreationDate()};
		return template.update(sql, params);

	}
	@Override
	public List<Bill> getBillList(Bill bill,int currentPageNo,int pageSize){
		StringBuffer sql = new StringBuffer();
		sql.append("select b.*,p.proName as providerName from smbms_bill b, smbms_provider p where b.providerId = p.id");
		List<Object> list = new ArrayList<Object>();
		if(!StringUtils.isNullOrEmpty(bill.getProductName())){
			sql.append(" and productName like ?");
			list.add("%"+bill.getProductName()+"%");
		}
		if(bill.getProviderId() > 0){
			sql.append(" and providerId = ?");
			list.add(bill.getProviderId());
		}
		if(bill.getIsPayment() > 0){
			sql.append(" and isPayment = ?");
			list.add(bill.getIsPayment());
		}
		sql.append(" order by creationDate DESC limit ?,?");
		currentPageNo = (currentPageNo - 1) * pageSize;
		list.add(currentPageNo);
		list.add(pageSize);
		Object[] params = list.toArray();
		List<Bill> listBill=template.query(sql.toString(), new BeanPropertyRowMapper<Bill>(Bill.class),params);
		return listBill;
	}
	@Override
	public int deleteBillById(String delId) {
		String sql = "delete from smbms_bill where id=?";
		Object[] params = {delId};
		return template.update(sql, delId);
	}

	@Override
	public Bill getBillById(String id)  {
		String sql = "select b.*,p.proName as providerName from smbms_bill b, smbms_provider p " +
				"where b.providerId = p.id and b.id=?";
		Object[] params = {id};
		return template.queryForObject(sql, new BeanPropertyRowMapper<Bill>(Bill.class), id);

	}

	@Override
	public int modify(Bill bill) {
		String sql = "update smbms_bill set productName=?," +
				"productDesc=?,productUnit=?,productCount=?,totalPrice=?," +
				"isPayment=?,providerId=?,modifyBy=?,modifyDate=? where id = ? ";
		Object[] params = {bill.getProductName(),bill.getProductDesc(),
				bill.getProductUnit(),bill.getProductCount(),bill.getTotalPrice(),bill.getIsPayment(),
				bill.getProviderId(),bill.getModifyBy(),bill.getModifyDate(),bill.getId()};
		return template.update(sql,params);
	}

	@Override
	public int getBillCountByProviderId(String providerId)  {
		String sql = "select count(1) as billCount from smbms_bill where" +
				"	providerId = ?";
		Object[] params = {providerId};
		return template.queryForObject(sql,Integer.class,params);
	}
	@Override
	public int 	getBillCount(Bill bill){
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT COUNT(1) FROM smbms_bill b, smbms_provider p WHERE b.providerId = p.id");
		//String sql = "";
		//Object[] params = {providerId};
		List<Object> list = new ArrayList<Object>();
		if (!StringUtils.isNullOrEmpty(bill.getProductName())) {
			sql.append(" and productName like ?");
			list.add("%" + bill.getProductName() + "%");
		}
		if (bill.getProviderId()>0) {
			sql.append(" and providerId = ?");
			list.add(bill.getProviderId());
		}
		if(bill.getIsPayment() >0 ){
			sql.append(" and isPayment = ?");
			list.add(bill.getIsPayment());
		}
		Object[] params = list.toArray();
		System.out.println("sql ----> " + sql.toString());
		System.out.println("params --->"+Arrays.toString(params));
		return template.queryForObject(sql.toString(),Integer.class,params);
	}
}
