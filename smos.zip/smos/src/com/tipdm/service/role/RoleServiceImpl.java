package com.tipdm.service.role;


import java.util.List;


import com.tipdm.dao.role.RoleDao;
import com.tipdm.dao.role.RoleDaoImpl;
import com.tipdm.domain.Role;

public class RoleServiceImpl implements RoleService{
	private RoleDao dao=new RoleDaoImpl();

	public List<Role> getRoleList()throws Exception{
		return dao.getRoleList();
	}
	
}
