package com.tipdm.service.role;

import java.util.List;


import com.tipdm.domain.Role;

public interface RoleService {

	public List<Role> getRoleList()throws Exception;
	
}
